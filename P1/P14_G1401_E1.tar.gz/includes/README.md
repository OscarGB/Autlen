Aquí van las cabeceras de las librerías implementadas
